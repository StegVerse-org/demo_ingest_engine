# StegVerse Demo Ingestion Engine

![Run Ingestion](https://github.com/StegVerse-org/demo_ingest_engine/actions/workflows/run-ingest.yml/badge.svg)
![Process Incoming](https://github.com/StegVerse-org/demo_ingest_engine/actions/workflows/process-incoming.yml/badge.svg)
![Python](https://img.shields.io/badge/python-3.11-blue)
![License](https://img.shields.io/github/license/StegVerse-org/demo_ingest_engine)

Release: v1.3.0  
Targets: stegverse-demo-suite, demo_suite_runner, demo_ingest_engine
