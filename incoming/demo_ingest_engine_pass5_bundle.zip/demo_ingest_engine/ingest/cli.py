from pathlib import Path
from datetime import datetime, timezone
import argparse
from .extract import extract_if_zip
from .config import ROOT
from .manifest import load_bundle_manifest, resolve_targets_from_manifest
from .orchestrator import resolve_targets, orchestrate_plan, orchestrate_install
from .report import write_json, write_markdown
from .detect import discover_zip_bundles

def parse_args():
    parser = argparse.ArgumentParser(description='StegVerse ingestion engine')
    sub = parser.add_subparsers(dest='cmd', required=True)
    p = sub.add_parser('plan'); p.add_argument('source'); p.add_argument('--target', dest='target_repo', default=None); p.add_argument('--target-set', default=None)
    i = sub.add_parser('install'); i.add_argument('source'); i.add_argument('--target', dest='target_repo', default=None); i.add_argument('--target-set', default=None); i.add_argument('--archive', action='store_true')
    o = sub.add_parser('orchestrate'); o.add_argument('source'); o.add_argument('--target-set', default=None); o.add_argument('--archive', action='store_true')
    a = sub.add_parser('process-all'); a.add_argument('--incoming-dir', default=str(ROOT/'incoming')); a.add_argument('--archive', action='store_true')
    return parser.parse_args()

def resolve_targets_for_run(manifest, target_repo, target_set):
    if not target_repo and not target_set:
        resolved = resolve_targets_from_manifest(manifest)
        if isinstance(resolved, list): return resolved
        if isinstance(resolved, dict) and resolved.get('target_set'): return resolve_targets(None, resolved['target_set'])
        return resolve_targets(None, 'runtime_stack')
    return resolve_targets(target_repo, target_set)

def run_one(source: Path, mode: str, target_repo=None, target_set=None, archive=False):
    stamp = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H-%M-%SZ')
    staging_root = ROOT/'staging'; work_root = ROOT/'updated_targets'/stamp; archive_root = ROOT/'deprecated'/stamp; reports_root = ROOT/'reports'
    source_dir = extract_if_zip(source, staging_root); manifest = load_bundle_manifest(source_dir); targets = resolve_targets_for_run(manifest, target_repo, target_set)
    if mode == 'plan':
        result_targets = orchestrate_plan(source_dir, targets, work_root); report = {'mode':'plan','source':str(source),'conflict_mode':'none','apply_mode':'preview','bundle_manifest':manifest,'targets':result_targets}
    else:
        use_archive = archive or bool(manifest and manifest.get('conflict_mode') == 'archive-and-replace')
        result_targets = orchestrate_install(source_dir, targets, work_root, archive_root, use_archive); report = {'mode':mode,'source':str(source),'conflict_mode':'archive-and-replace' if use_archive else 'replace','apply_mode':'artifact-only','bundle_manifest':manifest,'targets':result_targets}
    stem = source.stem; write_json(reports_root/f'{stem}_report.json', report); write_markdown(reports_root/f'{stem}_report.md', report); return report

def main():
    args = parse_args()
    if args.cmd == 'process-all':
        bundles = discover_zip_bundles(Path(args.incoming_dir)); results = []
        for bundle in bundles: results.append({'bundle': bundle.name, 'report': run_one(bundle, 'orchestrate', archive=args.archive)})
        write_json(ROOT/'reports'/'process_all_summary.json', {'bundle_count': len(results), 'results': results}); print(f'Processed bundles: {len(results)}'); return
    source = Path(args.source).resolve(); report = run_one(source, args.cmd, getattr(args, 'target_repo', None), getattr(args, 'target_set', None), getattr(args, 'archive', False)); print('Ingestion complete'); print(f"Targets: {len(report['targets'])}")

if __name__ == '__main__': main()
