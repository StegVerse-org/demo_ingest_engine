from .config import load_repos_config
from .git_ops import clone_repo
from .planner import build_plan
from .installer import install_files

def resolve_targets(target_repo, target_set):
    cfg = load_repos_config()
    if target_set: return cfg['target_sets'][target_set]
    if target_repo: return [target_repo]
    raise ValueError('Either target_repo or target_set must be provided')

def prepare_targets(target_names, work_root):
    cfg = load_repos_config(); prepared = {}
    for name in target_names:
        rcfg = cfg['repos'][name]; repo_dir = work_root / name; clone_repo(rcfg['clone_url'], repo_dir, branch=rcfg['default_branch']); prepared[name] = {'dir': repo_dir, 'config': rcfg}
    return prepared

def orchestrate_plan(source_dir, target_names, work_root):
    prepared = prepare_targets(target_names, work_root)
    return [build_plan(source_dir, item['dir'], item['config']['allowed_prefixes'], name) for name, item in prepared.items()]

def orchestrate_install(source_dir, target_names, work_root, archive_root, archive):
    prepared = prepare_targets(target_names, work_root)
    return [install_files(source_dir, item['dir'], item['config']['allowed_prefixes'], archive, archive_root, name) for name, item in prepared.items()]
