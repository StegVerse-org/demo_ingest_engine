# Artifact Evaluation Guide

Supported operations:
- plan
- install
- orchestrate
- process-all
