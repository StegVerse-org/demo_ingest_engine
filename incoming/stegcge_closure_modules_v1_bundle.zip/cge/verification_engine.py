from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Sequence

from .closure_planner import ClosurePlanner, ClosurePlan
from .dependency_graph import DependencyGraph
from .mutation_classifier import MutationClassifier, MutationClassification


@dataclass
class VerificationResult:
    decision: str
    reasons: list[str] = field(default_factory=list)
    changed_files: list[str] = field(default_factory=list)
    dependency_closure: list[str] = field(default_factory=list)
    missing_dependencies: list[str] = field(default_factory=list)
    closure_complete: bool = False
    mutation_type: str = "unknown_mutation"

    def as_dict(self) -> dict[str, Any]:
        return {
            "decision": self.decision,
            "reasons": list(self.reasons),
            "changed_files": list(self.changed_files),
            "dependency_closure": list(self.dependency_closure),
            "missing_dependencies": list(self.missing_dependencies),
            "closure_complete": self.closure_complete,
            "mutation_type": self.mutation_type,
        }


class VerificationEngine:
    """
    Dependency-aware verification engine.

    Backwards compatible usage:
        engine = VerificationEngine(repo_root=".")
        result = engine.verify_change(["path/a.py", "path/b.py"])

    It returns:
    - allow: closure is satisfied and no blocked paths detected
    - defer: mutation is coherent but incomplete relative to current dependency closure
    - deny: unsafe shape / invalid request
    """

    def __init__(self, repo_root: str | Path = ".") -> None:
        self.repo_root = Path(repo_root)
        self.dependency_graph = DependencyGraph(self.repo_root).build()
        self.closure_planner = ClosurePlanner(self.dependency_graph)
        self.mutation_classifier = MutationClassifier()

    def refresh_state(self) -> None:
        self.dependency_graph = DependencyGraph(self.repo_root).build()
        self.closure_planner = ClosurePlanner(self.dependency_graph)

    def verify_change(self, changed_files: Sequence[str] | dict[str, Any]) -> VerificationResult:
        files = self._extract_changed_files(changed_files)
        if not files:
            return VerificationResult(
                decision="deny",
                reasons=["No changed files supplied for verification."],
                changed_files=[],
                dependency_closure=[],
                missing_dependencies=[],
                closure_complete=False,
                mutation_type="unknown_mutation",
            )

        if any(self._is_blocked_path(f) for f in files):
            return VerificationResult(
                decision="deny",
                reasons=["Blocked path detected in proposed mutation set."],
                changed_files=sorted(files),
                dependency_closure=sorted(files),
                missing_dependencies=[],
                closure_complete=False,
                mutation_type="blocked_mutation",
            )

        classification = self.mutation_classifier.classify(files)
        closure = self.closure_planner.expand(files)

        decision = "allow" if closure.closure_complete else "defer"
        reasons = list(classification.reasons) + list(closure.notes)
        if not closure.closure_complete:
            reasons.append("All dependent files should be updated in the same admitted state transition.")

        return VerificationResult(
            decision=decision,
            reasons=reasons,
            changed_files=sorted(files),
            dependency_closure=list(closure.dependency_closure),
            missing_dependencies=list(closure.missing_dependencies),
            closure_complete=closure.closure_complete,
            mutation_type=classification.mutation_type,
        )

    def verify_proposal(self, proposal: dict[str, Any]) -> VerificationResult:
        return self.verify_change(proposal)

    def _extract_changed_files(self, payload: Sequence[str] | dict[str, Any]) -> list[str]:
        if isinstance(payload, dict):
            candidates = payload.get("changed_files") or payload.get("files") or []
            if isinstance(candidates, str):
                return [candidates.replace("\\", "/")]
            return [str(x).replace("\\", "/") for x in candidates]
        return [str(x).replace("\\", "/") for x in payload]

    def _is_blocked_path(self, rel_path: str) -> bool:
        blocked = [".git/", ".gitmodules", ".gitconfig"]
        norm = rel_path.replace("\\", "/")
        return any(token in norm for token in blocked)
