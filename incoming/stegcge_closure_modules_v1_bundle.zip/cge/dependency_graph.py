from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Set
import ast
import json


@dataclass
class DependencyGraph:
    """
    Lightweight same-repo dependency graph.

    v1 intentionally keeps resolution conservative:
    - Python import relationships from local modules
    - basic file-reference discovery in JSON / Markdown / YAML-ish text
    - reverse edges for impact analysis
    """
    root: str | Path
    forward: Dict[str, Set[str]] = field(default_factory=dict)
    reverse: Dict[str, Set[str]] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.root = str(Path(self.root))

    def build(self) -> "DependencyGraph":
        root = Path(self.root)
        self.forward.clear()
        self.reverse.clear()

        files = [p for p in root.rglob("*") if p.is_file() and ".git" not in p.parts]

        py_index = self._python_module_index(files)

        for path in files:
            rel = self._rel(path)
            deps: Set[str] = set()

            if path.suffix == ".py":
                deps |= self._python_dependencies(path, py_index)
            elif path.suffix in {".json", ".md", ".txt", ".yaml", ".yml"}:
                deps |= self._text_references(path, files)

            self.forward.setdefault(rel, set()).update(deps)
            for dep in deps:
                self.reverse.setdefault(dep, set()).add(rel)

        for rel in list(self.forward):
            self.reverse.setdefault(rel, set())
        return self

    def dependency_closure(self, changed_files: Iterable[str]) -> Set[str]:
        closure: Set[str] = set()
        stack: List[str] = [self._norm(f) for f in changed_files]

        while stack:
            current = stack.pop()
            if current in closure:
                continue
            closure.add(current)
            for dep in self.forward.get(current, set()):
                if dep not in closure:
                    stack.append(dep)
            for dependent in self.reverse.get(current, set()):
                if dependent not in closure:
                    stack.append(dependent)
        return closure

    def direct_dependencies(self, rel_path: str) -> Set[str]:
        return set(self.forward.get(self._norm(rel_path), set()))

    def direct_dependents(self, rel_path: str) -> Set[str]:
        return set(self.reverse.get(self._norm(rel_path), set()))

    def _rel(self, path: Path) -> str:
        return path.relative_to(self.root).as_posix()

    def _norm(self, rel_path: str) -> str:
        return Path(rel_path).as_posix()

    def _python_module_index(self, files: Iterable[Path]) -> Dict[str, str]:
        index: Dict[str, str] = {}
        for path in files:
            if path.suffix != ".py":
                continue
            rel = self._rel(path)
            if rel.endswith("/__init__.py"):
                module = rel[:-12].replace("/", ".")
            else:
                module = rel[:-3].replace("/", ".")
            if module:
                index[module] = rel
        return index

    def _python_dependencies(self, path: Path, py_index: Dict[str, str]) -> Set[str]:
        deps: Set[str] = set()
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except Exception:
            return deps

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    target = self._resolve_module(alias.name, py_index)
                    if target:
                        deps.add(target)
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    target = self._resolve_module(node.module, py_index)
                    if target:
                        deps.add(target)
        return deps

    def _resolve_module(self, module_name: str, py_index: Dict[str, str]) -> str | None:
        if module_name in py_index:
            return py_index[module_name]
        pieces = module_name.split(".")
        while pieces:
            candidate = ".".join(pieces)
            if candidate in py_index:
                return py_index[candidate]
            pieces.pop()
        return None

    def _text_references(self, path: Path, files: Iterable[Path]) -> Set[str]:
        deps: Set[str] = set()
        try:
            text = path.read_text(encoding="utf-8")
        except Exception:
            return deps

        rel_map = {self._rel(p): p for p in files}
        for rel in rel_map:
            if rel == self._rel(path):
                continue
            if rel in text or Path(rel).name in text:
                deps.add(rel)
        return deps
