from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from hashlib import sha256
from typing import Any


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _stable_hash(payload: dict[str, Any]) -> str:
    import json
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return sha256(canonical.encode("utf-8")).hexdigest()


@dataclass
class AcceptedChangeReceipt:
    receipt_type: str = "accepted_change_receipt"
    decision: str = "allow"
    mutation_type: str = "unknown_mutation"
    changed_files: list[str] = field(default_factory=list)
    dependency_closure: list[str] = field(default_factory=list)
    missing_dependencies: list[str] = field(default_factory=list)
    closure_complete: bool = False
    reasons: list[str] = field(default_factory=list)
    previous_state_hash: str | None = None
    resulting_state_hash: str | None = None
    created_at: str = field(default_factory=_utc_now)

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["receipt_hash"] = _stable_hash(payload)
        return payload

    @classmethod
    def from_verification_result(
        cls,
        verification_result: Any,
        previous_state_hash: str | None = None,
        resulting_state_hash: str | None = None,
    ) -> "AcceptedChangeReceipt":
        if hasattr(verification_result, "as_dict"):
            data = verification_result.as_dict()
        elif isinstance(verification_result, dict):
            data = verification_result
        else:
            raise TypeError("verification_result must be dict-like or expose as_dict().")

        return cls(
            decision=data.get("decision", "allow"),
            mutation_type=data.get("mutation_type", "unknown_mutation"),
            changed_files=list(data.get("changed_files", [])),
            dependency_closure=list(data.get("dependency_closure", [])),
            missing_dependencies=list(data.get("missing_dependencies", [])),
            closure_complete=bool(data.get("closure_complete", False)),
            reasons=list(data.get("reasons", [])),
            previous_state_hash=previous_state_hash,
            resulting_state_hash=resulting_state_hash,
        )
