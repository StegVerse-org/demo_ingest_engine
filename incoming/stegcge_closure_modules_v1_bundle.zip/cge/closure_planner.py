from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, List, Set

from .dependency_graph import DependencyGraph


@dataclass
class ClosurePlan:
    changed_files: List[str]
    dependency_closure: List[str]
    missing_dependencies: List[str]
    closure_complete: bool
    notes: List[str] = field(default_factory=list)

    def as_dict(self) -> dict:
        return {
            "changed_files": list(self.changed_files),
            "dependency_closure": list(self.dependency_closure),
            "missing_dependencies": list(self.missing_dependencies),
            "closure_complete": self.closure_complete,
            "notes": list(self.notes),
        }


class ClosurePlanner:
    """
    Computes the minimum dependency-aware mutation package for a proposed change set.
    """

    def __init__(self, dependency_graph: DependencyGraph) -> None:
        self.dependency_graph = dependency_graph

    def expand(self, changed_files: Iterable[str]) -> ClosurePlan:
        changed: Set[str] = {str(f).replace("\\", "/") for f in changed_files}
        closure = self.dependency_graph.dependency_closure(changed)
        missing = sorted(closure - changed)

        notes: List[str] = []
        if missing:
            notes.append("Dependency closure incomplete for proposed mutation set.")
        else:
            notes.append("Proposed mutation set satisfies current dependency closure.")

        return ClosurePlan(
            changed_files=sorted(changed),
            dependency_closure=sorted(closure),
            missing_dependencies=missing,
            closure_complete=not missing,
            notes=notes,
        )
