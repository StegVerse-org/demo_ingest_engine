from pathlib import Path

from cge.dependency_graph import DependencyGraph


def test_builds_forward_dependency_for_python_import(tmp_path: Path):
    pkg = tmp_path / "pkg"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "b.py").write_text("VALUE = 1\n", encoding="utf-8")
    (pkg / "a.py").write_text("from pkg.b import VALUE\n", encoding="utf-8")

    graph = DependencyGraph(tmp_path).build()
    assert "pkg/b.py" in graph.direct_dependencies("pkg/a.py")
