# CGE Closure Engine v1

This bundle adds dependency-closure awareness to StegCGE.

## What it adds

- `cge/dependency_graph.py`
- `cge/closure_planner.py`
- `cge/mutation_classifier.py`

## What it updates

- `cge/verification_engine.py`
- `cge/accepted_change_receipt.py`

## What changes conceptually

StegCGE now evaluates a change as a **state transition package** instead of a single-file mutation.

```text
proposal
  ↓
diff
  ↓
mutation classification
  ↓
dependency graph lookup
  ↓
closure expansion
  ↓
verification
  ↓
accepted change receipt
```

## Verification outcomes

- `allow` when the proposed file set already satisfies the dependency closure
- `defer` when the mutation is structurally valid but incomplete relative to the current dependency graph
- `deny` when blocked paths, invalid shapes, or irrecoverable issues are present

## Receipt additions

Accepted change receipts now include:

- `dependency_closure`
- `closure_complete`
- `missing_dependencies`
- `mutation_type`

## Notes

This bundle is intentionally conservative:
- static dependency detection first
- same-repo dependency closure only
- no automatic patch synthesis yet
